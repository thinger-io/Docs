// The MIT License (MIT)
//
// Copyright (c) 2017 THINK BIG LABS SL
// Author: alvarolb@gmail.com (Alvaro Luis Bustamante)
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifndef THINGER_TINY_GSM_H
#define THINGER_TINY_GSM_H

#include "ThingerClient.h"

#define NETWORK_REGISTER_TIMEOUT 15000
#define NETWORK_GPRS_TIMEOUT 15000

class ThingerTinyGSM : public ThingerClient {

public:
    ThingerTinyGSM(const char* user, const char* device, const char* device_credential, Stream& serial) :
        ThingerClient(client_, user, device, device_credential),
        modem_(serial),
        client_(modem_)
    {
    }

    ~ThingerTinyGSM(){

    }

    virtual bool initModem(std::function<void(TinyGsm&)> on_init = {}){
        // reset module
        if(module_reset_) module_reset_();
        bool init = modem_.init(pin_);
        if(init && on_init){
            on_init(modem_);
        }
        return init;
    }

protected:

    virtual bool network_connected(){
        RegStatus s = modem_.getRegistrationStatus();
        return (s == REG_OK_HOME || s == REG_OK_ROAMING);
    }

    void connect_socket_success() override{
        connection_errors_ = 0;
    }

    void connect_socket_error() override{
        connection_errors_++;
        if(connection_errors_==6){
            // soft reset the modem if socket cannot be connected in a while
            THINGER_DEBUG("NETWORK", "Soft-Restarting modem...");
            modem_.restart(pin_);
        }else if(connection_errors_==12){
            // still cannot connect after a soft-reset? -> hard reset
            THINGER_DEBUG("NETWORK", "Hard-Restarting modem...");
            initModem();
        }
    }

    virtual bool connect_network(){
        THINGER_DEBUG("NETWORK", "Waiting for network...");
        unsigned long network_timeout = millis();
        while (1)
        {
            RegStatus cereg = modem_.getRegistrationStatus();
            THINGER_DEBUG_VALUE("NETWORK", "CEREG: ", cereg);

            // connected    
            if (cereg == REG_OK_HOME || cereg == REG_OK_ROAMING){
                break;
            }

            // registration denied
            if(cereg==REG_DENIED){
                THINGER_DEBUG("NETWORK", "Connection denied by operator")
                // wait some time to not flood operator if sim is legitimately disabled
                delay(30000);
                // reset device
                initModem();
                return false;
            }

            // other ? i.e., 2, searching, or 0. reboot device if timed out
            if(millis() - network_timeout > 300000){
                THINGER_DEBUG("NETWORK", "Cannot connect network!")
                // reset device
                initModem();
                return false;
            }

            delay(500);
        }

        delay(100);
        THINGER_DEBUG("NETWORK", "Network registered...");

        if(!modem_.isGprsConnected()){
            THINGER_DEBUG("NETWORK", "Connecting to APN...")
            if (!modem_.gprsConnect(apn_, user_, password_)) {
                THINGER_DEBUG("NETWORK", "Cannot connect to APN!")
                return false;
            }
        }

        return true;
    }

#ifdef _DISABLE_TLS_
    virtual bool secure_connection(){
        return false;
    }
#endif

public:
    TinyGsm& getTinyGsm(){
        return modem_;
    }

    TinyGsmClient& getTinyGsmClient(){
        return client_;
    }

    void setAPN(const char* APN, const char* user=nullptr, const char* password=nullptr){
        apn_ = APN;
        user_ = user;
        password_ = password;
    }

    void setPIN(const char* pin){
        pin_ = pin;
    }

    void setModuleReset(std::function<void()> module_reset){
        module_reset_ = module_reset;
    }

private:
    const char* apn_        = nullptr;
    const char* user_       = nullptr;
    const char* password_   = nullptr;
    const char* pin_        = nullptr;
    uint8_t connection_errors_ = 0;
    TinyGsm modem_;
#ifdef _DISABLE_TLS_
    TinyGsmClient client_;
#else
    TinyGsmClientSecure client_;
#endif
    std::function<void()> module_reset_;
};

#endif