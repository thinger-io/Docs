#define USERNAME ""
#define DEVICE_ID ""
#define DEVICE_CREDENTIAL ""

// use your own APN config
#define APN_NAME "iot.1nce.net" //when working with 1nce
#define APN_USER ""
#define APN_PSWD ""

// set your cad pin (optional)
#define CARD_PIN ""